# extract_features.py
# Extract 29 structural features from UD treebanks
import glob, os, math, csv
from collections import Counter, defaultdict

BASE = '/Users/wideliazju.edu.cn/Desktop/all-treebank-6-7'

FILES = {
    'Azerbaijani':'Azerbaijani.conllu','Kazakh':'Kazakh.conllu','Kyrgyz':'Kyrgyz.conllu',
    'Tatar':'Tatar.conllu','Turkish':'Turkish_treebank.conllu','Uyghur':'Uyghur.conllu',
    'Uzbek':'Uzbek.conllu','Yakut':'Yakut.conllu','Buriat':'Buriat.conllu',
    'Daur':'Daur_treebank.conllu','Kalmyk':'Kalmyk_treebank.conllu',
    'Khalkha':'Mongolian (Khalkha)_treebank.conllu','Monguor':'Tu_treebank.conllu',
    'Ordos':'Ordos.conllu','Even':'Even_treebank.conllu','Evenki':'Evenki_treebank.conllu',
    'Manchu':'Manchu_treebank.conllu','Nanai':'Nanai_treebank.conllu','Negidal':'Negidal-ud.conllu',
    'Oroch':'Oroch_treebank.conllu','Udihe':'Udihe_treebank.conllu','Ulch':'Ulch_treebank.conllu',
    'Xibe':'Xibe.conllu','Japanese':'Japanese_treebank.conllu','Korean':'Korean_treebank.conllu',
    'Mandarin':'Chinese_treebank.conllu','Vietnamese':'Vietnamese_treebank.conllu','Hindi':'Hindi_treebank.conllu',
}

def parse(fp):
    sents, cur = [], []
    with open(fp, encoding='utf-8') as f:
        for line in f:
            if line.startswith('#'): continue
            if line.strip()=='':
                if cur: sents.append(cur); cur=[]
                continue
            c = line.rstrip('\n').split('\t')
            if len(c)!=10 or '-' in c[0] or '.' in c[0]: continue
            try:
                cur.append({'id':int(c[0]),'upos':c[3],
                            'head':int(c[6]) if c[6]!='_' else -1,
                            'deprel':c[7].split(':')[0]})
            except: continue
        if cur: sents.append(cur)
    return [s for s in sents if sum(1 for t in s if t['head']==0)==1]

def extract(sents):
    HI=HF=0; rel_dir=defaultdict(lambda:[0,0]); rel=Counter(); dists=[]
    n_obj=0; n_verb=0; n_sent=len(sents)
    for sent in sents:
        for t in sent:
            if t['head']==0 or t['head']==-1 or t['deprel']=='punct': continue
            rel[t['deprel']]+=1
            if t['head']<t['id']: HI+=1; rel_dir[t['deprel']][0]+=1
            else: HF+=1; rel_dir[t['deprel']][1]+=1
            dists.append(abs(t['head']-t['id']))
            if t['deprel']=='obj': n_obj+=1
        for t in sent:
            if t['upos']=='VERB': n_verb+=1
    f={}; tot=HI+HF
    if tot>0:
        pHI,pHF=HI/tot,HF/tot
        f['DDir_global']=pHI
        f['H_dir']=-sum(p*math.log2(p) for p in (pHI,pHF) if p>0)
    for r,(hi,hf) in rel_dir.items():
        if (hi+hf)>0: f[f'DDir_{r}']=hi/(hi+hf)
    tr=sum(rel.values())
    if tr>0: f['H_rel']=-sum((c/tr)*math.log2(c/tr) for c in rel.values())
    if dists:
        m=sum(dists)/len(dists); f['MDD']=m
        f['VarDL']=sum((d-m)**2 for d in dists)/len(dists)
    nd=tot
    if nd>0:
        f['CCompRatio']=rel['ccomp']/nd; f['AdvclRatio']=rel['advcl']/nd
        f['AclRatio']=rel['acl']/nd; f['CoordRatio']=rel['conj']/nd
        f['CaseRatio']=rel['case']/nd
        f['Transitivity']=n_obj/n_verb if n_verb>0 else None
    return f

results={}
for lang,fn in FILES.items():
    results[lang]=extract(parse(os.path.join(BASE,fn)))

# final 29 features (after dropping high-missing + DDir_balance + collinearity)
KEEP=['DDir_acl','DDir_advcl','DDir_advmod','DDir_amod','DDir_case','DDir_cc',
      'DDir_ccomp','DDir_compound','DDir_conj','DDir_det','DDir_discourse',
      'DDir_global','DDir_nmod','DDir_nsubj','DDir_nummod','DDir_obj','DDir_obl',
      'DDir_parataxis','DDir_xcomp','H_dir','H_rel','MDD','VarDL',
      'CCompRatio','AdvclRatio','AclRatio','CoordRatio','Transitivity','CaseRatio']
with open(os.path.join(BASE,'features_final_29.csv'),'w',newline='',encoding='utf-8') as w:
    cw=csv.writer(w); cw.writerow(['language']+KEEP)
    for lang in FILES:
        cw.writerow([lang]+[results[lang].get(k,'') for k in KEEP])
print("done: features_final_29.csv")