# signal_and_trees.R
# Phylogenetic signal testing (Pagel's lambda, Blomberg's K) under 4 topologies,
# plus distance-based NJ trees.
library(phytools)
library(ape)
setwd("/Users/wideliazju.edu.cn/Desktop/all-treebank-6-7")

# ---- branches ----
TK <- "Azerbaijani,Kazakh,Kyrgyz,Tatar,Turkish,Uyghur,Uzbek,Yakut"
MN <- "Buriat,Daur,Kalmyk,Khalkha,Monguor,Ordos"
TG <- "Even,Evenki,Manchu,Nanai,Negidal,Oroch,Udihe,Ulch,Xibe"
JP <- "Japanese"; KR <- "Korean"; OUT <- "Mandarin,Vietnamese,Hindi"
g <- function(s) paste0("(", s, ")")
JK <- sprintf("(%s,%s)", JP, KR)

# ---- 4 reference topologies ----
H1 <- sprintf("((%s,%s,(%s,%s)),%s);", g(TG), JK, g(MN), g(TK), OUT)
H2 <- sprintf("(((%s,%s),(%s,%s)),%s);", g(TG), JK, g(MN), g(TK), OUT)
H3 <- sprintf("(((%s,(%s,%s)),%s),%s);", g(TG), g(MN), g(TK), JK, OUT)
H4 <- sprintf("(((%s,(%s,%s)),%s),%s);", g(TK), g(MN), g(TG), JK, OUT)
trees <- list(H1=H1, H2=H2, H3=H3, H4=H4)

ref_trees <- list()
for (nm in names(trees)) {
  t <- multi2di(read.tree(text=trees[[nm]]))
  t$edge.length <- rep(1, nrow(t$edge))
  ref_trees[[nm]] <- t
}

# ---- signal testing ----
d <- read.csv("features_final_29.csv", row.names=1)
features <- colnames(d)

for (tree_name in names(ref_trees)) {
  tree <- ref_trees[[tree_name]]
  lambda_val<-lambda_p<-K_val<-K_p<-setNames(rep(NA,length(features)),features)
  for (f in features) {
    x <- d[[f]]; names(x) <- rownames(d); x <- x[!is.na(x)]
    if (length(x)<5 || var(x)==0) next
    tr <- drop.tip(tree, setdiff(tree$tip.label, names(x)))
    x  <- x[tr$tip.label]
    lam <- tryCatch(phylosig(tr, x, method="lambda", test=TRUE), error=function(e) NULL)
    bk  <- tryCatch(phylosig(tr, x, method="K", test=TRUE, nsim=999), error=function(e) NULL)
    if(!is.null(lam)){lambda_val[f]<-lam$lambda; lambda_p[f]<-lam$P}
    if(!is.null(bk)) {K_val[f]<-bk$K; K_p[f]<-bk$P}
  }
  res <- data.frame(feature=features,
                    lambda=round(lambda_val,3), lambda_p=round(lambda_p,4),
                    lambda_FDR=round(p.adjust(lambda_p,"BH"),4),
                    K=round(K_val,3), K_p=round(K_p,4),
                    K_FDR=round(p.adjust(K_p,"BH"),4))
  write.csv(res, paste0("signal_", tree_name, ".csv"), row.names=FALSE)
  strict  <- sum(res$lambda_FDR<0.05 & res$K_FDR<0.05, na.rm=TRUE)
  relaxed <- sum(res$lambda_FDR<0.1  | res$K_FDR<0.1,  na.rm=TRUE)
  cat(sprintf("%s: strict=%d relaxed=%d\n", tree_name, strict, relaxed))
}

# ---- NJ trees from signal-selected features ----
res1 <- read.csv("signal_H1.csv")
strict_feats  <- res1$feature[which(res1$lambda_FDR<0.05 & res1$K_FDR<0.05)]
relaxed_feats <- res1$feature[which(res1$lambda_FDR<0.1  | res1$K_FDR<0.1)]
strict_feats  <- strict_feats[!is.na(strict_feats)]
relaxed_feats <- relaxed_feats[!is.na(relaxed_feats)]

build_nj <- function(feat_set, tag) {
  X <- d[, feat_set, drop=FALSE]
  for (j in 1:ncol(X)) X[is.na(X[,j]), j] <- mean(X[,j], na.rm=TRUE)
  Xz <- scale(X)
  tr <- nj(dist(Xz))
  set.seed(42)
  bs <- boot.phylo(tr, Xz, function(xx) nj(dist(xx)), B=1000, quiet=TRUE)
  tr$node.label <- bs
  write.tree(tr, paste0("tree_", tag, ".nwk"))
  pdf(paste0("tree_", tag, "_phylogram.pdf"), width=8, height=10)
  plot(tr, cex=0.8, main=paste("NJ -", tag)); nodelabels(tr$node.label, cex=0.55, frame="none")
  dev.off()
}
build_nj(strict_feats, "strict")
build_nj(relaxed_feats, "relaxed")
cat("NJ trees written.\n")